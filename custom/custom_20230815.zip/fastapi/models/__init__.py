from . import fastapi_endpoint
from . import fastapi_endpoint_demo
from . import shipment_order_service
from . import ir_rule
from . import res_lang
