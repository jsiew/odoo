`generic.mixin.uuid`: now if uuid is specified during object creation, it will not be regenerated, instead provided value will be used.
