Added new function useful in migration, especially, mergin modules:
- `generic_mixin.tools.migration_utils.migrate_xmlids_to_module`
- `generic_mixin.tools.migration_utils.cleanup_module_data`
