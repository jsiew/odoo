General purpouse web 3d view using three.js
