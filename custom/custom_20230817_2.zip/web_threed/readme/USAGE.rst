To use this module, you need to install and use with apps like stock3d_view and mrp_3dview
