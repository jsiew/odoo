Removed `no_tag_id` field in favor of `search_no_tag_id`
