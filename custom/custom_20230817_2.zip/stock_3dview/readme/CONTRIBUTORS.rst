* Andrea Piovesana <andrea.m.piovesana@gmail.com>
* Loris Tissino <loris.tissino@gmail.com>
* Davide Corio <me@davidecorio.com>
* Matteo Boscolo <matteo.boscolo.76@gmail.com>
* PhilDL <contact@codingdodo.com>
