To use this module, you need to:

#. Go to 'Stock / Settings / Location'
#. you can filter locations by warehouse
