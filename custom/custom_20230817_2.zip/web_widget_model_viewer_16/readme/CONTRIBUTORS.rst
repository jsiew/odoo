* Lorenzo Battistini (https://takobi.online)
* Andrea Piovesana (https://openindustry.it)
* Marco Colombo (https://phi.technology)
* PhilDL (https://codingdodo.com)
