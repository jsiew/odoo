.. image:: https://img.shields.io/badge/licence-AGPL--3-blue.svg
   :target: http://www.gnu.org/licenses/agpl-3.0-standalone.html
   :alt: License: AGPL-3

=================
Stock 3dview base
=================

Module

Credits
=======

Contributors
------------
* Andrea Piovesana <andrea.m.piovesana@gmail.com>
* Loris Tissino <loris.tissino@gmail.com>
* PhilDL <contact@codingdodo.com>

Sponsors
--------
* `Openindustry.it <https://openindustry.it>`__

Maintainers
-----------
* `Openindustry.it <https://openindustry.it>`__

      To get a guaranteed support
      you are kindly requested to purchase the module
      at `odoo apps store <https://apps.odoo.com/>`__.

      Thanks

Further information
===================

HTML Description: https://apps.odoo.com/apps/modules/16.0/stock_3dbase/

Usage instructions: `<readme/USAGE.rst>`_

Changelog: `<readme/HISTORY.rst>`_

