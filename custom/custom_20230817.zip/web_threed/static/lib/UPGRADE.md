# If you want to upgrade the three.js library, you need to follow these steps:

<version> = 0.146.0

```
cd /web_threed/static/src/js/libs
wget https://cdnjs.cloudflare.com/ajax/libs/three.js/<version>/three.min.js
wget https://unpkg.com/three@<version>/examples/js/controls/OrbitControls.js
wget https://unpkg.com/three@<version>/examples/js/loaders/GLTFLoader.js
```