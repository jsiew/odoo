# aiohttp-graphql tests
