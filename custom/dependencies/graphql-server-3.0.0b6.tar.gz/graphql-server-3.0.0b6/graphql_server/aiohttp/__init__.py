from .graphqlview import GraphQLView

__all__ = ["GraphQLView"]
