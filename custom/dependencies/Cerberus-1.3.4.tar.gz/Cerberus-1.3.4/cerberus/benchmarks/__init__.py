from pathlib import Path


DOCUMENTS_PATH = Path(__file__).parent / "documents"
